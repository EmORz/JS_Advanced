function aggregate (input){
    let sum =0;

    let concats;

    for (let i = 0; i < input.length; i++){
        sum+=Number(input[i]);
        concats += input[i]+"";
    }
    console.log(sum)
    console.log((concats))
}

aggregate([2, 4, 8, 16]);