function circleArea(input){

    let temp = typeof(input[0]);
    if(temp =='number'){
        let r = Number(input[0]);

        let area = Math.PI * r * r;
        console.log(area.toFixed(2));
    }
  

    
    else {
        console.log('Its not a number!')
    }

}

circleArea([5])