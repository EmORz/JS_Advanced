function mathOperation(input){

    let operation = input[2];

    let result;

    switch(operation){
        case '+': result=input[0]+input[1];
        break;
        case '-': result=input[0]-input[1];
        break;
        case '*': result=input[0]*input[1];
        break;
        case '/': result=input[0]/input[1];
        break;
        case '%': result=input[0]+input[1];
        break;
    }

    console.log(result);


}

mathOperation([3, 5.5, '*'])