
function StrLenght(input){

    let arr1 = input[0].length;
    let arr2 = input[1].length;
    let arr3 = input[2].length;

    let sum = arr1+arr2+arr3;
    let average = Math.floor(sum / 3);

    console.log(sum)
    console.log(average);

}

StrLenght(['pasta', '5', '22.3'])